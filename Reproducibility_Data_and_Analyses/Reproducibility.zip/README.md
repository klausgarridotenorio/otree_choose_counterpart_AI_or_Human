# Data_Handling_AI_Favoritism

## Replicate the experiment

The oTree code to replicate the experiment can be found in otree_experiment.zip


## Replicate the data cleaning

### STEP 1
Running the notebook: 339_Sample/Automated_CSV_Cleaning_339.ipynb 
- Inputs the data collected from each experimental Otree session. 
-- (From folder Data_Collection_Raw)
- Output 0: Formats the raw data in every file. 
-- (To folder Data_Collection_Clean)
- Output 1: Merges the individual data files into a single one. 
(excluding those participants that failed the comprehension check)
-- (To 339_Sample/Data_Cleaned_339.csv)
- Output 2: Individual data files are prepared for ROBUSTNESS CHECK of hypothesis testing 
-- (To 339_Sample/339_Hypothesis_1.csv, 339_Sample/339_Hypothesis_2.csv, 
339_Sample/339_Hypothesis_3_and_4.csv)

Importantly, due to the bug encountered in "Private_information_analysis/339_lies_bot.ipynb"
 we report the analyses with the sample of 288 participants who experienced a chatbot requesting
private information.

### STEP 2
Running the notebook:
/Data_Handling_AI_Favoritism/Private_information_analysis/339_lies_bot.ipynb
- Inputs the data cleaned from Step 1 Data_Cleaned_339. 

- Outputs: A list of unique participants who experienced a chatbot requesting
private information. 
(Private_information_analysis/participants_that_did_not_experienced_bot_bug.csv)

### STEP 3
Running the notebook: Automated_CSV_Cleaning_288.ipynb
- Inputs the data cleaned from Step 1 Data_Cleaned_339 and from Step 2

- Output 0: Excludes those participants who experienced a problematic chatbot.
-- (To Data_Cleaned_288.csv)
- Output 1: Individual data files are prepared for hypothesis testing 
-- (To 288_Hypothesis_1.csv, 288_Hypothesis_2.csv, 288_Hypothesis_3_and_4.csv)


## Replicate the data analysis

### Page-by-page transparency 

#### Experimental Protocol: 

As stated in our study pre-registration, those who failed the comprehension check minimum of three times
(n=9) are excluded from the analysis. 
-> File: Automated_CSV_Cleaning.ipynb

15% of Participants experienced at least once a bot that did not request private information. 
-> File: "Private_information_analysis/339_lies_bot.ipynb"

#### Results 

0.35% were not profitable for the hybrid chatbot. 
-> File: Automated_CSV_Cleaning_288.ipynb
(0.44% Both Full Sample and 339)

1st paragraph Operational Outcomes
-> File: Tables/Agreement_rate.Rmd

2nd and 3rd paragraph Operational Outcomes (H1)
-> File: Hypothesis Testing/Hypothesis_1.Rmd

4th paragraph Operational Outcomes (Robustness H1)
-> File: Hypothesis Testing/Hypothesis_1_Role_Specific.Rmd

5th and 6th paragraph Operational Outcomes (H2)
-> File: Hypothesis Testing/Hypothesis_2.Rmd

6th paragraph Operational Outcomes (Robustness H2)
-> File: Tables/priv_info_analysis_post_hoc.Rmd

1st paragraph Preference for Artificial Negotiation Counterparts
-> File: Hypothesis Testing/Hypothesis_3.Rmd

3rd and 4th paragraph Preference for Artificial Negotiation Counterparts
-> File: Hypothesis Testing/Hypothesis_4.Rmd

2nd and 3rd paragraph Post-Hoc analysis:
-> File: Tables/priv_info_analysis_post_hoc.Rmd

5th paragraph Post-Hoc analysis:
-> File: Tables/Pareto_Efficient_Profit_Split.Rmd (First sentence)
-> File: Hypothesis Testing/Hypothesis_1.Rmd 

Tables:
Agreement rates by pie size
-> File: Tables/Agreement_rate.Rmd

Linear Mixed-Effects Model: Dependent variable Actual Profit and Pre-Negotiation Expected Profit.
-> File: Hypothesis Testing/Hypothesis_1.Rmd
-> File: Hypothesis Testing/Hypothesis_2.Rmd

Logistic Regression Model: Dependent variable Likelihood to choose a Bot
-> File: Hypothesis Testing/Hypothesis_4.Rmd

Figures:
Player Profit by Counterpart Nature and Private Information Disclosure
-> File: /Private_information_analysis/Priv_info_disclosure_to_profit_and_over_rounds.ipynb

Appendix: Robustness Analysis on Full Sample and 339 Sample
-> Folder: /Full_Sample 
-> Folder: /339_Sample


